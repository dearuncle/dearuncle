import sys
import json
from pathlib import Path
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QMessageBox,
    QDialog, QListWidget, QLineEdit, QPushButton, QLabel, QVBoxLayout, QHBoxLayout, QWidget, QComboBox, QInputDialog
)
from PyQt5 import uic

BASE_DIR = Path(__file__).resolve().parent
REPORTS_FILE = BASE_DIR / "reports.json"
GRAFANA_REPORTS = {}

def load_reports():
    global GRAFANA_REPORTS
    if REPORTS_FILE.exists():
        with open(REPORTS_FILE, "r", encoding="utf-8") as f:
            GRAFANA_REPORTS = json.load(f)
    else:
        GRAFANA_REPORTS = {}

def save_reports():
    with open(REPORTS_FILE, "w", encoding="utf-8") as f:
        json.dump(GRAFANA_REPORTS, f, indent=2, ensure_ascii=False)

class ReportEditor(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("리포트 관리")
        self.setMinimumWidth(400)
        layout = QVBoxLayout()

        self.listWidget = QListWidget()
        layout.addWidget(QLabel("리포트 목록"))
        layout.addWidget(self.listWidget)

        btn_layout = QHBoxLayout()
        self.btn_add = QPushButton("➕ 추가")
        self.btn_edit = QPushButton("✏️ 수정")
        self.btn_delete = QPushButton("🗑 삭제")
        self.btn_close = QPushButton("💾 저장하고 닫기")
        btn_layout.addWidget(self.btn_add)
        btn_layout.addWidget(self.btn_edit)
        btn_layout.addWidget(self.btn_delete)
        btn_layout.addWidget(self.btn_close)
        layout.addLayout(btn_layout)

        self.setLayout(layout)
        self.refresh_list()

        self.btn_add.clicked.connect(self.add_report)
        self.btn_edit.clicked.connect(self.edit_report)
        self.btn_delete.clicked.connect(self.delete_report)
        self.btn_close.clicked.connect(self.save_and_close)

    def refresh_list(self):
        self.listWidget.clear()
        for name in GRAFANA_REPORTS:
            self.listWidget.addItem(name)

    def add_report(self):
        name, ok = QInputDialog.getText(self, "새 리포트 이름", "리포트 이름:")
        if ok and name and name not in GRAFANA_REPORTS:
            GRAFANA_REPORTS[name] = {"url": "", "panels": []}
            self.refresh_list()

    def edit_report(self):
        current = self.listWidget.currentItem()
        if not current:
            return
        name = current.text()
        url, ok1 = QInputDialog.getText(self, "URL 수정", "URL:", text=GRAFANA_REPORTS[name]["url"])
        if not ok1:
            return
        panels, ok2 = QInputDialog.getText(self, "패널 목록", "패널명 (쉼표로 구분):", text=", ".join(GRAFANA_REPORTS[name]["panels"]))
        if not ok2:
            return
        GRAFANA_REPORTS[name]["url"] = url
        GRAFANA_REPORTS[name]["panels"] = [p.strip() for p in panels.split(",") if p.strip()]
        self.refresh_list()

    def delete_report(self):
        current = self.listWidget.currentItem()
        if not current:
            return
        name = current.text()
        confirm = QMessageBox.question(self, "삭제 확인", f"{name} 리포트를 삭제할까요?")
        if confirm == QMessageBox.Yes:
            del GRAFANA_REPORTS[name]
            self.refresh_list()

    def save_and_close(self):
        save_reports()
        self.accept()

class GrafanaApp(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi(str(BASE_DIR / "ui" / "grafana_ui_labeled.ui"), self)

        load_reports()
        self.comboReport.addItems(GRAFANA_REPORTS.keys())

        self.comboReport.currentTextChanged.connect(self.on_report_selected)
        self.btnManage.clicked.connect(self.open_report_editor)

        if self.comboReport.count() > 0:
            self.on_report_selected(self.comboReport.currentText())

    def on_report_selected(self, report_name):
        data = GRAFANA_REPORTS.get(report_name)
        if data:
            self.inputURL.setText(data.get("url", ""))
            self.comboPanel.clear()
            self.comboPanel.addItems(data.get("panels", []))

    def open_report_editor(self):
        dialog = ReportEditor(self)
        if dialog.exec_():
            self.comboReport.clear()
            self.comboReport.addItems(GRAFANA_REPORTS.keys())
            if self.comboReport.count() > 0:
                self.on_report_selected(self.comboReport.currentText())

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = GrafanaApp()
    win.show()
    sys.exit(app.exec_())
