import os
import time
import glob
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

def download_grafana_panels(GRAFANA_URL, GRAFANA_USER, GRAFANA_PASS,
                             TARGET_PANEL_TITLES, CSV_DOWNLOAD_DIR, log):
    chrome_options = Options()
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": os.path.abspath(CSV_DOWNLOAD_DIR),
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })

    driver = webdriver.Chrome(options=chrome_options)

    try:
        driver.get(GRAFANA_URL)
        time.sleep(2)

        driver.find_element(By.NAME, "user").send_keys(GRAFANA_USER)
        driver.find_element(By.NAME, "password").send_keys(GRAFANA_PASS)
        driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
        time.sleep(3)
        driver.get(GRAFANA_URL)
        time.sleep(5)

        for title in TARGET_PANEL_TITLES:
            try:
                log(f"▶ 패널 찾는 중: {title}")
                section = driver.find_element(By.CSS_SELECTOR, f'section[data-testid*="Panel header {title}"]')
                driver.execute_script("arguments[0].scrollIntoView();", section)
                menu_button = section.find_element(By.CSS_SELECTOR, f'button[data-testid*="Panel menu {title}"]')
                menu_button.click()
                time.sleep(1)
                driver.find_element(By.XPATH, "//span[text()='Inspect']").click()
                time.sleep(1)
                driver.find_element(By.XPATH, "//span[text()='Download CSV']").click()
                log(f"📥 CSV 다운로드: {title}")
                time.sleep(5)

                latest_csv = max(glob.glob(os.path.join(CSV_DOWNLOAD_DIR, "*.csv")), key=os.path.getctime)
                df = pd.read_csv(latest_csv)
                xlsx_path = os.path.splitext(latest_csv)[0] + ".xlsx"
                df.to_excel(xlsx_path, index=False)
                log(f"📊 변환 완료: {xlsx_path}")

            except Exception as e:
                log(f"❌ 패널 처리 오류: {e}")

    except Exception as e:
        log(f"❌ 전체 오류: {e}")
    finally:
        driver.quit()
