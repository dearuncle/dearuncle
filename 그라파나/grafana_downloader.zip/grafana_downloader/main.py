import sys
import threading
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox
from .ui_grafana import Ui_MainWindow
from .downloader import download_grafana_panels

class GrafanaApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # UI 연결
        self.ui.btnBrowse.clicked.connect(self.browse_folder)
        self.ui.btnStart.clicked.connect(self.start_download)
        self.ui.btnExit.clicked.connect(self.close)

    def log(self, message):
        self.ui.textLog.append(message)

    def browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "저장 폴더 선택")
        if folder:
            self.ui.inputFolder.setText(folder)

    def start_download(self):
        url = self.ui.inputURL.text()
        user = self.ui.inputUser.text()
        pw = self.ui.inputPassword.text()
        panel = self.ui.comboPanel.currentText()
        folder = self.ui.inputFolder.text()

        if not url or not user or not pw or not panel or not folder:
            QMessageBox.warning(self, "입력 오류", "모든 항목을 입력하세요.")
            return

        self.log(f"▶ URL: {url}")
        self.log(f"▶ 패널: {panel}")
        self.log(f"▶ 저장경로: {folder}")

        threading.Thread(target=download_grafana_panels, kwargs={
            "GRAFANA_URL": url,
            "GRAFANA_USER": user,
            "GRAFANA_PASS": pw,
            "TARGET_PANEL_TITLES": [panel],
            "CSV_DOWNLOAD_DIR": folder,
            "log": self.log
        }).start()

def run():
    app = QApplication(sys.argv)
    win = GrafanaApp()
    win.show()
    sys.exit(app.exec_())
