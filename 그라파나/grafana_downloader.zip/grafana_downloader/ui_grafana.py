from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setWindowTitle("Grafana 패널 다운로드 툴")
        MainWindow.resize(600, 500)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        layout = QtWidgets.QVBoxLayout(self.centralwidget)

        self.inputURL = QtWidgets.QLineEdit()
        self.inputURL.setPlaceholderText("Grafana 대시보드 URL")
        layout.addWidget(QtWidgets.QLabel("대시보드 URL"))
        layout.addWidget(self.inputURL)

        self.inputUser = QtWidgets.QLineEdit()
        self.inputUser.setPlaceholderText("사용자 ID")
        layout.addWidget(QtWidgets.QLabel("사용자 ID"))
        layout.addWidget(self.inputUser)

        self.inputPassword = QtWidgets.QLineEdit()
        self.inputPassword.setEchoMode(QtWidgets.QLineEdit.Password)
        self.inputPassword.setPlaceholderText("비밀번호")
        layout.addWidget(QtWidgets.QLabel("비밀번호"))
        layout.addWidget(self.inputPassword)

        self.comboPanel = QtWidgets.QComboBox()
        self.comboPanel.addItems(["한전FTP전송내역", "롯데FTP전송내역"])
        layout.addWidget(QtWidgets.QLabel("패널 선택"))
        layout.addWidget(self.comboPanel)

        path_layout = QtWidgets.QHBoxLayout()
        self.inputFolder = QtWidgets.QLineEdit()
        self.btnBrowse = QtWidgets.QPushButton("찾아보기")
        path_layout.addWidget(self.inputFolder)
        path_layout.addWidget(self.btnBrowse)
        layout.addWidget(QtWidgets.QLabel("저장 경로"))
        layout.addLayout(path_layout)

        self.btnStart = QtWidgets.QPushButton("다운로드 시작")
        self.btnExit = QtWidgets.QPushButton("종료")
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addWidget(self.btnStart)
        btn_layout.addWidget(self.btnExit)
        layout.addLayout(btn_layout)

        self.textLog = QtWidgets.QTextEdit()
        self.textLog.setReadOnly(True)
        layout.addWidget(QtWidgets.QLabel("로그 출력"))
        layout.addWidget(self.textLog)

        MainWindow.setCentralWidget(self.centralwidget)
