import sys, os, json
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QFileDialog, QMessageBox, QDialog, QVBoxLayout, QLabel, QLineEdit, QTextEdit, QPushButton, QComboBox, QListWidget

class ReportManager(QDialog):
    def __init__(self, reports_path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("리포트 관리")
        self.resize(500, 300)
        self.reports_path = reports_path
        self.load_reports()
        self.layout = QVBoxLayout(self)

        self.list = QListWidget()
        self.list.addItems(self.reports.keys())
        self.layout.addWidget(self.list)

        self.edit_url = QLineEdit()
        self.layout.addWidget(QLabel("URL:"))
        self.layout.addWidget(self.edit_url)

        self.edit_panels = QLineEdit()
        self.layout.addWidget(QLabel("패널 목록 (쉼표 구분):"))
        self.layout.addWidget(self.edit_panels)

        btns = QtWidgets.QHBoxLayout()
        self.btn_add = QPushButton("추가")
        self.btn_edit = QPushButton("수정")
        self.btn_delete = QPushButton("삭제")
        btns.addWidget(self.btn_add)
        btns.addWidget(self.btn_edit)
        btns.addWidget(self.btn_delete)
        self.layout.addLayout(btns)

        self.btn_add.clicked.connect(self.add_report)
        self.btn_edit.clicked.connect(self.edit_report)
        self.btn_delete.clicked.connect(self.delete_report)
        self.list.itemSelectionChanged.connect(self.fill_fields)

    def load_reports(self):
        if os.path.exists(self.reports_path):
            with open(self.reports_path, "r", encoding="utf-8") as f:
                self.reports = json.load(f)
        else:
            self.reports = {}

    def save_reports(self):
        with open(self.reports_path, "w", encoding="utf-8") as f:
            json.dump(self.reports, f, indent=2, ensure_ascii=False)

    def fill_fields(self):
        item = self.list.currentItem()
        if not item: return
        name = item.text()
        self.edit_url.setText(self.reports[name]["url"])
        self.edit_panels.setText(", ".join(self.reports[name]["panels"]))

    def add_report(self):
        name, ok = QtWidgets.QInputDialog.getText(self, "리포트 이름", "새 리포트 이름 입력:")
        if ok and name:
            self.reports[name] = {"url": "", "panels": []}
            self.list.addItem(name)
            self.list.setCurrentRow(self.list.count() - 1)

    def edit_report(self):
        item = self.list.currentItem()
        if not item: return
        name = item.text()
        self.reports[name]["url"] = self.edit_url.text().strip()
        self.reports[name]["panels"] = [p.strip() for p in self.edit_panels.text().split(",") if p.strip()]
        self.save_reports()

    def delete_report(self):
        item = self.list.currentItem()
        if not item: return
        name = item.text()
        reply = QMessageBox.question(self, "삭제 확인", f"'{name}' 리포트를 삭제할까요?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.reports.pop(name, None)
            self.list.takeItem(self.list.row(item))
            self.edit_url.clear()
            self.edit_panels.clear()
            self.save_reports()

class GrafanaApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("ui/grafana_ui_labeled.ui", self)
        self.reports_path = "reports.json"
        self.comboReport.currentTextChanged.connect(self.load_selected_report)
        self.btnManage.clicked.connect(self.open_report_manager)
        self.btnDownload.clicked.connect(self.start_download)
        self.logText.setStyleSheet("background-color: black; color: lime;")
        self.load_reports()

    def log(self, msg):
        self.logText.append(msg)

    def load_reports(self):
        if os.path.exists(self.reports_path):
            with open(self.reports_path, "r", encoding="utf-8") as f:
                self.reports = json.load(f)
        else:
            self.reports = {}
        self.comboReport.clear()
        self.comboReport.addItems(self.reports.keys())
        if self.reports:
            self.load_selected_report(self.comboReport.currentText())

    def load_selected_report(self, name):
        if name in self.reports:
            self.inputURL.setText(self.reports[name]["url"])
            self.comboPanel.clear()
            self.comboPanel.addItems(self.reports[name]["panels"])

    def open_report_manager(self):
        dlg = ReportManager(self.reports_path, self)
        if dlg.exec_() == QDialog.Accepted:
            self.load_reports()

    def start_download(self):
        report = self.comboReport.currentText()
        panel = self.comboPanel.currentText()
        self.log(f"📥 다운로드 요청됨: {report} / {panel}")
        QMessageBox.information(self, "알림", "여기에 다운로드 코드 연동 예정입니다.")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    win = GrafanaApp()
    win.show()
    sys.exit(app.exec_())
